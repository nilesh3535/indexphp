<?php
// index.php

// Redirect to login.php
header("Location: ./screens/login.php");
exit(); // Stop further execution of the script
?>
